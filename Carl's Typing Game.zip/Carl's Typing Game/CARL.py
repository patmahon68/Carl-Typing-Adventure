from pygame import *
from math import *
from random import *
import textwrap
page = 9
init()
size = width, height = 1024, 768
screen = display.set_mode(size)
display.set_caption("Carl's Bodacious Adventure")

def linesP(sA):
    space=1
    for i in sA:
        space+=1
        charPic=perFont.render(i,True,(0,0,0))
        screen.blit(charPic,(55,180+60*space))

def linesT(sA):
    space=1
    for i in sA:
        space+=1
        charPic=perFont.render(i,True,(200,200,200))
        screen.blit(charPic,(55,180+60*space))

def linesC(sA):
    space=1
    for i in sA:
        space+=1
        charPic=textFont.render(i,True,(0,0,0))
        screen.blit(charPic,(315,-75+50*space))

def linesW(sA):
    space=1
    for i in sA:
        space+=1
        charPic=perFont.render(i,True,(255,0,0))
        screen.blit(charPic,(55,180+60*space))

####defining all rects####

##characters##
carl_character= Rect(200,150, 500,500)

##tools##

startRect = Rect(348, 586, 350, 170)
textboxRect = Rect(290, 10, 700, 200)
typeboxRect =  Rect(50, 300, 924, 500)



####load ALL images####
##wallpapers##
wallpaper = transform.scale(image.load('Backgrounds/start_screen.png'), (1024, 768))
wallpaper2 = transform.scale(image.load('Backgrounds/blue_background.jpg'), (1024, 768))
gameOv =transform.scale(image.load('Backgrounds/PixelArt.png'), (1024, 768))


##U.I.##
# textboxDesign = transform.scale(image.load('Backgrounds/textbox_border.png'), (700, 200))
# typeboxDesign = transform.scale(image.load('Backgrounds/textbox_border.png'), (924, 500))

##Characters##
carl = transform.scale(image.load('Characters/carl_character.png'), (200, 150))
carlos = transform.scale(image.load('Characters/carlos.png'), (200, 150))
carlina = transform.scale(image.load('Characters/carlina.png'), (200, 150))

worm = transform.scale(image.load('Characters/worm.png'), (55,50))


##global##
start = False
myClock = time.Clock()
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
LIMEGREEN = (255, 255, 100)
textFont = font.Font('Fonts/pixel.ttf', 30)
perFont = font.Font('Fonts/pixel.ttf', 45)

setup = True
running = True
stopped = False
print_wrong = True


def wrap(s,w):
    wrapper = textwrap.TextWrapper(width=w)
    return wrapper.wrap(text=s)


def start():
    running = True
    while running:
        for evt in event.get():
            if evt.type == QUIT:
                running = False
        mx,my = mouse.get_pos()
        mb = mouse.get_pressed()
        screen.blit(wallpaper, (0, 0))
        draw.rect(screen, BLACK, startRect, 5)
        if startRect.collidepoint(mx, my):
            draw.rect(screen, RED, startRect, 5)
            if mb[0] == 1:
                return 1
        display.flip()


#def transition():
    #hey put a transition here
def stage1(n):
    mealwormNum = 10
    name_list = []
    print_wrong = True
    print("a")
    if n == 9 or n>10:
        char = carlos
        print('los')
    else:
        char = carl
    characterL = ["""Yikes... You lose part of your lifeforce whenever you make a typo?""","""Anything else I need to know""","""Hey, Carl's my friend. I can't be sure if he's an idiot yet, but it's not nice to call anyone an idiot, even idiots.""", """I don't think I can just ignore him""","""Yes."""]
    valueL = ["""The first thing you need to know about hedgehog typing every mistake we make costs us 1 lifeforce.""","""Yes, so don't mess up. Five mistakes and I'm going to bed hungry.""", """HEY CARL YOU IDIOT""","""That's Carlina's brother Carlos, ignore him""","""You want to fight? You wimpy human?"""]
    characterList = characterL[n-7]
    print(characterList)
    typed = ""
    wrong = ""
    value = valueL[n-7]
    screen.blit(wallpaper2, (0, 0))
    screen.blit(char, (50, 80))

    draw.rect(screen, WHITE, textboxRect)
    draw.rect(screen, WHITE, typeboxRect)

    # screen.blit(textboxDesign, (290,10))
    # screen.blit(typeboxDesign, (50, 250))

    running = True
    while running:
        click = False
        for evt in event.get():
            if evt.type == QUIT:
                running = False
            if evt.type == KEYUP:
                if evt.key == K_a:
                    name_list.append("a")
                elif evt.key == K_b:
                    name_list.append("b")
                elif evt.key == K_c:
                    name_list.append("c")
                elif evt.key == K_d:
                    name_list.append("d")
                elif evt.key == K_e:
                    name_list.append("e")
                elif evt.key == K_f:
                    name_list.append("f")
                elif evt.key == K_g:
                    name_list.append("g")
                elif evt.key == K_h:
                    name_list.append("h")
                elif evt.key == K_i:
                    name_list.append("i")
                elif evt.key == K_j:
                    name_list.append("j")
                elif evt.key == K_k:
                    name_list.append("k")
                elif evt.key == K_l:
                    name_list.append("l")
                elif evt.key == K_m:
                    name_list.append("m")
                elif evt.key == K_n:
                    name_list.append("n")
                elif evt.key == K_o:
                    name_list.append("o")
                elif evt.key == K_p:
                    name_list.append("p")
                elif evt.key == K_q:
                    name_list.append("q")
                elif evt.key == K_r:
                    name_list.append("r")
                elif evt.key == K_s:
                    name_list.append("s")
                elif evt.key == K_t:
                    name_list.append("t")
                elif evt.key == K_u:
                    name_list.append("u")
                elif evt.key == K_v:
                    name_list.append("v")
                elif evt.key == K_w:
                    name_list.append("w")
                elif evt.key == K_x:
                    name_list.append("x")
                elif evt.key == K_y:
                    name_list.append("y")
                elif evt.key == K_z:
                    name_list.append("z")
                elif evt.key == K_SPACE:
                    name_list.append(" ")
                elif evt.key == K_SLASH:
                    name_list.append("?")
                elif evt.key == K_COMMA:
                    name_list.append(",")
                elif evt.key == K_PERIOD:
                    name_list.append(".")
                elif evt.key == K_QUOTE:
                    name_list.append("'")

            mb = mouse.get_pressed()
            mx, my = mouse.get_pos()

            if name_list and name_list[-1] == characterList[0].lower():
                typed += characterList[0]
                wrong += characterList[0]
                name_list = []
                characterList = characterList[1:]
                if len(wrong) > len(typed):
                    wrong = wrong[:-1]
                    print_wrong = True

            elif name_list and name_list[-1] != characterList[0].lower():
                if print_wrong == True:
                    mealwormNum -= 1
                    wrong += characterList[0]
                    linesW(wrap(wrong, 25))
                    print_wrong = False
            if mealwormNum == 0:
                return -1
        screen.blit(wallpaper2, (0, 0))
        screen.blit(char, (50, 80))

        draw.rect(screen, WHITE, textboxRect)
        draw.rect(screen, WHITE, typeboxRect)

        linesP(wrap(characterL[n-7], 27))
        linesC(wrap(value, 30))
        linesW(wrap(wrong, 27))
        linesT(wrap(typed, 27))
        for i in range(mealwormNum):
            screen.blit(worm, (300 + 50 * i, 225))

###blit all icons###
        display.flip()
        myClock.tick(500)
        if len(characterList) == 0:
            return n+1
def game(n):
    name_list = []
    print_wrong = True
    print("a")
    #if n == 6:
     #   transition()
    characterL = ["""Who would do such a thing to a being as pure as you? I don't know you, and I am not attracted to hedgehogs, but I feel you would be attractive for a hedgehog.""","""My god, what can you do to see her again? Is there any way I can help you? Anything you need, I am at your disposal.""","""And I could help you pass Carl. I'm a bit of a scholar myself, specifically in typing and political science""","""We can do a reverse ratituoue, I love that movie. I'll follow you, and whenever you need to type I can switch out.""", """Well, you seem very kind, and I don't have any friends""","""Let's get Carlina"""]
    valueL = ["""My name is Carl and I am a hedgehog. Today, the love of my life left me.""","""It was not the decision of my lover or me: ours was a forbidden love.""", """There is one thing: Carlina's family rejected me because I failed out of school""", """Perfect. The class I failed was typing. My hog hands aren't nimble enough""","""You'd do that for a stranger? A strange hog passing by?""","""You do now."""]
    characterList = characterL[n]
    print(characterList)
    typed = ""
    wrong = ""
    value = valueL[n]
    screen.blit(wallpaper2, (0, 0))
    screen.blit(carl, (50, 80))
    draw.rect(screen, WHITE, textboxRect)
    draw.rect(screen, WHITE, typeboxRect)
    # screen.blit(textboxDesign, (290,10))
    # screen.blit(typeboxDesign, (50, 250))

    print("b")
    running = True
    while running:
        click = False
        for evt in event.get():
            if evt.type == QUIT:
                running = False
            if evt.type == KEYUP:
                if evt.key == K_a:
                    name_list.append("a")
                elif evt.key == K_b:
                    name_list.append("b")
                elif evt.key == K_c:
                    name_list.append("c")
                elif evt.key == K_d:
                    name_list.append("d")
                elif evt.key == K_e:
                    name_list.append("e")
                elif evt.key == K_f:
                    name_list.append("f")
                elif evt.key == K_g:
                    name_list.append("g")
                elif evt.key == K_h:
                    name_list.append("h")
                elif evt.key == K_i:
                    name_list.append("i")
                elif evt.key == K_j:
                    name_list.append("j")
                elif evt.key == K_k:
                    name_list.append("k")
                elif evt.key == K_l:
                    name_list.append("l")
                elif evt.key == K_m:
                    name_list.append("m")
                elif evt.key == K_n:
                    name_list.append("n")
                elif evt.key == K_o:
                    name_list.append("o")
                elif evt.key == K_p:
                    name_list.append("p")
                elif evt.key == K_q:
                    name_list.append("q")
                elif evt.key == K_r:
                    name_list.append("r")
                elif evt.key == K_s:
                    name_list.append("s")
                elif evt.key == K_t:
                    name_list.append("t")
                elif evt.key == K_u:
                    name_list.append("u")
                elif evt.key == K_v:
                    name_list.append("v")
                elif evt.key == K_w:
                    name_list.append("w")
                elif evt.key == K_x:
                    name_list.append("x")
                elif evt.key == K_y:
                    name_list.append("y")
                elif evt.key == K_z:
                    name_list.append("z")
                elif evt.key == K_SPACE:
                    name_list.append(" ")
                elif evt.key == K_SLASH:
                    name_list.append("?")
                elif evt.key == K_COMMA:
                    name_list.append(",")
                elif evt.key == K_PERIOD:
                    name_list.append(".")
                elif evt.key == K_QUOTE:
                    name_list.append("'")

            mb = mouse.get_pressed()
            mx, my = mouse.get_pos()

            if name_list and name_list[-1] == characterList[0].lower():

                typed += characterList[0]
                wrong += characterList[0]
                name_list = []
                characterList = characterList[1:]
                if len(wrong) > len(typed):
                    wrong = wrong[:-1]
                    print_wrong = True

            elif name_list and name_list[-1] != characterList[0].lower():
                if print_wrong == True:
                    wrong += characterList[0]
                    linesW(wrap(wrong, 25))
                    print_wrong = False
        draw.rect(screen, WHITE, typeboxRect)
        linesP(wrap(characterL[n], 27))
        linesC(wrap(value, 30))
        linesW(wrap(wrong, 27))
        linesT(wrap(typed, 27))
###blit all icons###
        display.flip()
        myClock.tick(500)
        if len(characterList) == 0:
            return n+2
def gameOver():
    screen.blit(gameOv,(0,0))
    return "EXIT"
while page!="EXIT":
    print("page is ", page)
    if page ==  0:
        page = start()
    if page > 0 and page < 7:
        page = game(page-1)
    if page >6 and page < 12:
        page = stage1(page)
    if page == -1:
        page = gameOver()
quit()

