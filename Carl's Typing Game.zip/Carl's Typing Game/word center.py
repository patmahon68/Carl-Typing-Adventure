from pygame import *


size = width, height = 1024, 768
screen = display.set_mode(size)
display.set_caption("Carl's Bodacious Adventure")
font = font.Font('Fonts/pixel.ttf', 30)

def name():
    init()
    font.init()
    screen = display.set_mode((480, 360))
    name = ""
    font = font.Font(None, 50)

    while True:
        for evt in event.get():
            if evt.type == KEYDOWN:
                if evt.unicode.isalpha():
                    name += evt.unicode
                elif evt.key == K_BACKSPACE:
                    name = name[:-1]
                elif evt.key == K_RETURN:
                    name = ""
            elif evt.type == QUIT:
                return

    screen.fill((0, 0, 0))
    block = font.render(name, True, (255, 255, 255))

    rect = block.get_rect()
    rect.center = screen.get_rect().center
    screen.blit(block, rect)
    display.flip()
name()